Replace these 9 role images on Cascade at the same paths, then re-paste roles pages.
