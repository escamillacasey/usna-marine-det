Upload these 9 files to Cascade at the same paths.
Then re-paste all three roles pages (ground paste changed engineer path).

Source mapping:
  infantry.avif -> ground/infantry.jpg
  engineer.avif -> ground/engineer.jfif
  acv.avif -> ground/acv.jpg
  recon_in_the_rain.avif -> ground/egr.jpg
  ch53.avif -> aviation/ch53.jpg
  j35-2.avif -> aviation/f35.png
  UH1Y2.avif -> aviation/uh1y.png
  comm2.avif -> support/communications.jpg
  logistics.jpg -> support/logistics.jpg
